from setuptools import setup, find_packages

setup(
    name='onboarding',
    packages=find_packages(include=[
        'onboarding',
        'onboarding.utils',
        'onboarding.static',
        'onboarding.config_modifier',
        'onboarding.static.codes',
        'onboarding.static.config',
        'onboarding.static.credentials'
    ]),
    data_files=[
        ('config', ['onboarding/static/config/doc_config.json']),
        ('credentials', ['onboarding/static/credentials/ocrvenv-43bd1e531883.json'])
    ],
    version='1.0.1',
    description='document scanner and perspective corrector',
    long_description="After importing onboarding we have to use ScannerRunner method that takes an argument 'destination folder'. It has run method which takes image path that must be transformed.",
    long_description_content_type="text/markdown",
    author='R&D TBC',
    license='MIT',
    install_requires=['pillow', 'opencv-python', 'numpy', 'google-cloud-vision'],
    setup_requires=[],
    test_suite='tests',
    include_package_data=True,
)