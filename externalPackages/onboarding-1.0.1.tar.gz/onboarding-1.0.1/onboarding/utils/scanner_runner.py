import json
import os
import time
from collections import defaultdict
from pathlib import Path
from typing import Optional
from PIL import Image
from onboarding.static.variables import TRANSFORM_INFO, PERSONAL_INFO
from onboarding.utils.scanned_image import ScannedImage


class ScannerRunner:
    def __init__(self,
                 dst_dir: Optional[str],
                 failed_subfolder: bool = False,
                 doctype_subfolder: bool = False
                 ):
        self.dst_dir = Path(dst_dir) if dst_dir else None
        self.failed_subolder = failed_subfolder
        self.doctype_subfolder = doctype_subfolder
        self.log = defaultdict(list)

    def run(self, img_path, show_image=False) -> tuple[Image, dict]:
        st = time.time()
        info = {TRANSFORM_INFO: "N/A", PERSONAL_INFO: "N/A"}
        scanned_image = ScannedImage(img_path)
        scanned_image.fill_info(info)
        self.log[Path(img_path).name].append(f"ScannedImage was Created -- elapsed time: {round(time.time() - st, 3)}")
        self.log[Path(img_path).name].append(f"Doctype: {scanned_image.doc_type}")

        transformer = scanned_image.get_best_transformer()
        out_dir = self.dst_dir / scanned_image.doc_type if self.doctype_subfolder else self.dst_dir
        out_image = None
        et = time.time()
        self.log[Path(img_path).name].append(
            f"DocTransformer was Created -- elapsed time: {round(time.time() - st, 3)}")
        if transformer is None:
            self.log[Path(img_path).name].append("NOT Transformed")

            if self.failed_subolder is not None:
                out_dir = out_dir / "failed_transformation_data"

            try:
                out_image = Image.open(img_path)
                # Save output
                if self.dst_dir is not None:
                    os.makedirs(out_dir, exist_ok=True)
                    out_image.save(out_dir / Path(img_path).name)
                    with open(out_dir / Path(img_path).with_suffix('.json').name, 'w') as f:
                        f.write(json.dumps(info, indent=4))
                self.log[Path(img_path).name].append(f"data Saved -- elapsed time: {round(time.time() - st, 3)}")
            except Exception as e:
                self.log[Path(img_path).name].append(f"data Not Saved -- elapsed time: {round(time.time() - st, 3)}. "
                                                     f"Error: {str(e)}")

        else:
            self.log[Path(img_path).name].append("Transformed")
            transformer.fill_info(info)
            try:
                out_image, _ = transformer.get_transformed_image(img_path)
                if show_image:
                    out_image.show()

                # save output
                if self.dst_dir is not None:
                    os.makedirs(out_dir, exist_ok=True)
                    out_image.save(out_dir / Path(img_path).name)
                    with open(out_dir / Path(img_path).with_suffix(".json").name, 'w') as f:
                        f.write(json.dumps(info, indent=4))
                self.log[Path(img_path).name].append(f"data Saved -- elapsed time: {round(time.time() - st, 3)}")
            except Exception as e:
                self.log[Path(img_path).name].append(f"data NOT Saved -- elapsed time: {round(time.time() - st, 3)}. "
                                                     f"Error: {str(e)}")

        return out_image, info
