import cv2
import numpy as np
from PIL import Image
from typing import Dict, Optional
from onboarding.static.variables import *
from onboarding.static.codes.functions import bounding_box_to_point, get_personal_info


# Class used to transform image and its annotations
class DocTransformer:
    def __init__(self, scanned_annotations: Dict, target_info: Dict, quadrangle: list):
        self.input_annotations = bounding_box_to_point(scanned_annotations)
        self.target_info = target_info
        self.quadrangle = quadrangle
        self.transformation_matrix = self.__find_trans_matrix()
        self.transformed_annotations = self.__transform_annotations()

    def __find_trans_matrix(self) -> Optional[np.ndarray]:
        if not self.quadrangle:
            return None
        target_annotations = self.target_info[TARGET_ANNOTATIONS]
        input_points = np.float32(list(self.input_annotations[desc] for desc in self.quadrangle))
        output_points = np.float32(list(target_annotations[desc] for desc in self.quadrangle))
        assert (len(input_points) == len(output_points) == 4)
        return cv2.getPerspectiveTransform(input_points, output_points)

    def __transform_annotations(self) -> Optional[Dict]:
        if self.transformation_matrix is None:
            return None
        transformed_annotations = {}
        for description, point in self.input_annotations.items():
            inp_vec = np.append(np.array(point), 1)
            out_vec = self.transformation_matrix.dot(inp_vec)
            out_vec = out_vec / out_vec[2]
            transformed_annotations[description] = list(out_vec[:-1])
        return transformed_annotations

    # Public function used to transform image
    def get_transformed_image(self, image_path) -> tuple[Image, Image]:
        # TODO deal with the case when it is not transformable
        with Image.open(image_path) as img:
            img_array = np.array(img)
            transformed_img_arr = cv2.warpPerspective(
                img_array,
                self.transformation_matrix,
                self.target_info[TARGET_RESOLUTION]
            )
        photo_bounds = self.target_info[PERSONAL_INFO].get(PHOTO, None)
        if photo_bounds:
            portrait_arr = transformed_img_arr[photo_bounds[0]: photo_bounds[1], photo_bounds[2]:photo_bounds[3]]
            portrait_arr = Image.fromarray(portrait_arr)
        else:
            portrait_arr = None
        return Image.fromarray(transformed_img_arr), portrait_arr

    # Calculates max distance(normalized by image size) between transformed annotations and target annotations.
    # Score of 0 is the best possible score.
    def get_score(self) -> (int, list, list):
        if self.transformed_annotations is None:
            return SCORE_THRESHOLD
        common_descriptions = (self.input_annotations.keys() & self.target_info[TARGET_ANNOTATIONS]).difference(
            NON_SCORING_DESCRIPTIONS)
        target_annotations = self.target_info[TARGET_ANNOTATIONS]
        x_scale, y_scale = self.target_info[TARGET_RESOLUTION]
        deviations = []
        for desc in common_descriptions:
            target_x, target_y = target_annotations[desc]
            src_x, src_y = self.transformed_annotations[desc]
            distance = ((target_x - src_x) / x_scale) ** 2 + ((target_y - src_y) / y_scale) ** 2
            distance = np.sqrt(distance)
            deviations.append(distance)
        return max(deviations), deviations, common_descriptions

    # checks transformed annotations and gets id number, first_name and last_name
    # if found on appropriate position
    def get_personal_info(self) -> dict:
        out = {}
        for personal_info_type, bounds in self.target_info[PERSONAL_INFO].items():
            if personal_info_type == PHOTO:
                continue
            info = get_personal_info(self.transformed_annotations, bounds, personal_info_type)
            if info is not None:
                out[personal_info_type] = info
        return out

    def fill_info(self, dictionary: dict):
        score, deviations, descriptions = self.get_score()
        dictionary[TRANSFORM_INFO] = {
            "TRANSFORM_SCORE": score,
            "SCORE_TABLE": dict(sorted(zip(descriptions, deviations), key=lambda x: -x[1])),
            "TRANSFORMATION_QUADRANGLE": self.quadrangle,
            "TRANSFORMED_ANNOTATIONS": self.transformed_annotations
        }
        dictionary[PERSONAL_INFO] = self.get_personal_info()
