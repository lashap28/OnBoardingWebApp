import io
import json
from typing import Optional, Dict
from onboarding.static.variables import *
from onboarding.static.codes.doc_type import DocType
from onboarding.static.codes.functions import parse_annotations, bounding_box_to_point
from google.cloud import vision
from onboarding.static.codes.vision_client_connect import Credentials
from google.cloud.vision_v1 import AnnotateImageResponse
from onboarding.static.variables import CONFIG_PATH
from onboarding.utils.doc_transformer import DocTransformer


#from onboarding.utils.doc_transformer import DocTransformer


# Used to get ocr data and generate transformer class instance
class ScannedImage:
    def __init__(self,
                 img_dir: Optional[str],
                 ocr_json: json = None):
        self.ocr_data = ocr_json if ocr_json else self.ocr_result(img_dir)
        self.scanned_annotations = parse_annotations(self.ocr_data)
        self.doc_type = DocType(self.scanned_annotations.keys()).get_doctype_str()
        self.doc_subtype = None

    def ocr_result(self, img_dir):
        with io.open(img_dir, 'rb') as f:
            byte_image = f.read()
        image = vision.Image(content=byte_image)
        data_ocr = Credentials().CLIENT.text_detection(image=image)
        serialized_proto_plus = AnnotateImageResponse.serialize(data_ocr)
        data_json = AnnotateImageResponse.deserialize(serialized_proto_plus)
        data_json = AnnotateImageResponse.to_json(data_json)
        return json.loads(data_json)

    # Returns subdict of config with the only keys that correspond to doctype
    def config_parser(self) -> Dict:
        with open(CONFIG_PATH, "r") as f:
            data_config = json.loads(f.read())
        keys = data_config.keys()
        doc_subtypes = [i for i in keys if self.doc_type.lower() in i.lower()]
        return dict((subtype, data_config[subtype]) for subtype in doc_subtypes)

    # {k: data_config[k] for k in keys if self.doc_type.lower() in k.lower()}

    # Loops through subtypes containing doctype and through quadrangles and returns the Doctransformer
    # instance with the best possible score
    def get_best_transformer(self) -> Optional[DocTransformer]:
        config_sub_dict = self.config_parser()
        output_transformer = None
        best_score = 1
        for subtype, target_info in config_sub_dict.items():
            # target_info = {'target_annotations: ..., 'quad_candidates': ...., 'target_resolution'}
            valid_quadrangles = self.get_valid_quadrangles(target_info)
            for quadrangle in valid_quadrangles:
                transformer = DocTransformer(self.scanned_annotations, target_info, quadrangle)
                score, deviations, descriptions = transformer.get_score()
                if score < best_score:
                    best_score = score
                    output_transformer = transformer
                    self.doc_subtype = subtype
        return output_transformer

    # Returns the list of quadrangles that are subset of scanned descriptions
    def get_valid_quadrangles(self, target_info):
        valid_quadrangles = []
        input_annotations = bounding_box_to_point(self.scanned_annotations)
        for quadrangle in target_info[QUAD_CANDIDATES]:
            if set(quadrangle).issubset(input_annotations.keys()):
                valid_quadrangles.append(quadrangle)
        return valid_quadrangles

    def fill_info(self, dictionary):
        dictionary[OCR] = self.ocr_data
        dictionary[ANNOTATIONS] = self.scanned_annotations
        dictionary[DOCTYPE] = self.doc_type

        for description in self.scanned_annotations.keys():
            if len(description) == 11 and description.isnumeric():
                dictionary[PERSONAL_INFO] = {ID_NUM: description}
                return
