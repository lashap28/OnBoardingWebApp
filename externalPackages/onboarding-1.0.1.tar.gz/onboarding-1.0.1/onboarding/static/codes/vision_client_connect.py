from google.cloud import vision
from google.oauth2 import service_account
from dataclasses import dataclass
from onboarding.static.variables import CREDENTIALS_PATH

@dataclass
class Credentials:
    CREDENTIALS = service_account.Credentials.from_service_account_file(
        filename=str(CREDENTIALS_PATH),
        scopes=['https://www.googleapis.com/auth/cloud-platform']
    )
    CLIENT = vision.ImageAnnotatorClient(credentials=CREDENTIALS)

