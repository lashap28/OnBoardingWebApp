from typing import Optional
from onboarding.static.codes.functions import is_georgian


# Clas that is used to determine document_type
class DocType:
    def __init__(self, annotation_keys):
        self.__descriptions = annotation_keys
        self.type = 'UNKNOWN'
        self.nation = 'UNKNOWN'
        self.set_nation()
        self.set_type()
        self.sure_check()

    # sets nation the document issued by
    def set_nation(self):
        for word in self.__descriptions:
            if word in {'GEO', 'RUS', 'UKR', 'IND', 'AZE', 'BLR', 'FRA'}:
                self.nation = word
                return

    # sets type of document
    def set_type(self):
        if 'PASSPORT' in self.__descriptions or {'P', '<'}.issubset(self.__descriptions):
            if self.nation == 'UKR':
                self.type = 'id_front'
            else:
                self.type = 'passport'
        elif "IDENTITY" in self.__descriptions or {"PERSONAL", "No"}.issubset(self.__descriptions) \
                or {"PERSONAL", "CIT"}.issubset(self.__descriptions) or {"CARD", "No"}.issubset(self.__descriptions):
            self.type = 'id_front'
        elif {"ISSUING", "AUTHORITY", "JUSTICE"}.issubset(self.__descriptions):
            self.type = 'id_back'
        elif "DRIVING" in self.__descriptions or "LICENCE" in self.__descriptions or "MIA" in self.__descriptions:
            self.type = 'dl_front'
        elif "licence" in self.__descriptions or "C1E" in self.__descriptions or "D1E" in self.__descriptions:
            self.type = 'dl_back'

    # checks if it is a passport or id_back. overrides old values self.nation and self.type
    def sure_check(self):
        for word in self.__descriptions:
            if word[:5] == 'IDGEO' or word[:5] == "IDGE0":
                self.nation = 'GEO'
                self.type = 'id_back'
                break
        # checks if the document contains a georgian letter. overrides self.nation
        for word in self.__descriptions:
            if len(word) > 2 and all(is_georgian(c) for c in word):
                self.nation = 'GEO'
                return
        return

    # returns doctype + nationality (only geo for now)
    def get_doctype_str(self) -> Optional[str]:
        return f'{self.type}_{self.nation}'

    def to_dict(self):
        return {"NATION": self.nation, "TYPE": self.type}
