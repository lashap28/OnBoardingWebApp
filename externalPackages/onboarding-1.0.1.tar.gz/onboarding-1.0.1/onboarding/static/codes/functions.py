from typing import Dict, Optional
import re
from onboarding.static.variables import ID_NUM, FIRST_NAME, LAST_NAME


def parse_annotations(data: dict) -> dict:
    out = dict()
    for entity in data["textAnnotations"][1:]:
        text = entity["description"]
        #     if not text_is_valid(text):
        #         continue
        bounding_vertices = entity["boundingPoly"]["vertices"]
        coordinates = [(p["x"], p["y"]) for p in bounding_vertices]
        # we need last description for ...<<<, and first for everything else
        if text[-3:] == "<<<":
            out["<<<_gela"] = coordinates
        else:
            out.setdefault(text, coordinates)
        # out[text] = coordinates
    return out


def is_georgian(c: chr) -> bool:
    return 4300 <= ord(c) <= 4336


# maps bounding points to middle, left and right points with new corresponding keys
# We allow this to modify key, "IDGEO*****" -> "IDGEO" and "P<GEO*****" -> "P<GEO"
def bounding_box_to_point(annotations: Dict) -> Dict:
    out_annotations = {}
    for description, bounding_box in annotations.items():
        if description[0] == '/':
            continue
        if description[:5] in {'IDGEO', "IDGE0"}:
            out_annotations["IDGEO"] = find_point(bounding_box, 'left')
        elif is_date(description):
            out_annotations["date_gela"] = find_point(bounding_box, 'left')
        elif is_georgian(description[0]):
            key = re.sub(r"[ბ|გ]", '*', description)
            out_annotations[key] = find_point(bounding_box, 'middle')
            out_annotations[key + '_l'] = find_point(bounding_box, 'left')
            out_annotations[key + '_r'] = find_point(bounding_box, 'right')
        elif description == "<<<_gela":
            out_annotations[description] = find_point(bounding_box, 'right')
        else:
            out_annotations[description] = find_point(bounding_box, 'middle')
            out_annotations[description + '_l'] = find_point(bounding_box, 'left')
            out_annotations[description + '_r'] = find_point(bounding_box, 'right')
    return out_annotations


# finds middle, left or right point from the bounding box
def find_point(bounding_box: list, method: str = 'middle') -> tuple:
    if method == 'middle':
        x, y = 0, 0
        for point in bounding_box:
            x += point[0]
            y += point[1]
        return x / 4, y / 4
    elif method == 'left':
        x = (bounding_box[0][0] + bounding_box[3][0]) / 2
        y = (bounding_box[0][1] + bounding_box[3][1]) / 2
        return x, y
    elif method == 'right':
        x = (bounding_box[1][0] + bounding_box[2][0]) / 2
        y = (bounding_box[1][1] + bounding_box[2][1]) / 2
        return x, y
    else:
        raise Exception("invalid method")


def is_date(s: str) -> bool:
    if len(s) != 10:
        return False
    parts = s.split('.')
    return len(parts) == 3 and all(list(part.isdigit() for part in parts))


# returns personal id number or None
def get_personal_info(transformed_annotations: dict, bounds: list, info_type: str) -> Optional[int]:
    for description, coordinates in transformed_annotations.items():
        if bounds[0] <= coordinates[0] <= bounds[1] and bounds[2] <= coordinates[1] <= bounds[3]:
            if info_type == ID_NUM and description.isdigit() and len(description) == 11:
                return description
            elif info_type in [FIRST_NAME, LAST_NAME] and all(ord('A') <= ord(c) <= ord('z') for c in description):
                # is English word
                return description
    return None
