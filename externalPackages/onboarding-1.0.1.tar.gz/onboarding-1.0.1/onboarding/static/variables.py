# ScannedImage output dictionary keys
import pathlib

DOCTYPE = "DOCTYPE"
OCR = "OCR"
ANNOTATIONS = "ANNOTATIONS"
PERSONAL_INFO = "PERSONAL_INFO"
TRANSFORM_INFO = "TRANSFORM_INFO"
DIRECTORIES = "DIRECTORIES"
SRC = "SRC"
DST = "DST"
ID_NUM = "ID_NUM"
PHOTO = "PHOTO"
FACE_VERIFIED = "Face_Verified"

# config dict keys
TARGET_ANNOTATIONS = "target_annotations"
TARGET_RESOLUTION = "target_resolution"
QUAD_CANDIDATES = "quad_candidates"

# PERSONAL_INFO = "PERSONAL_INFO"
SCORE_THRESHOLD = 1

# PERSONAL INFO KEYS
# ID_NUM = "ID_NUM"
FIRST_NAME = "FIRST_NAME"
LAST_NAME = "LAST_NAME"


NON_SCORING_DESCRIPTIONS = {
    "date_gela",
    "<<<_gela"
}

# Paths
ROOT_DIR = pathlib.Path(__file__).parent.parent
CONFIG_PATH = ROOT_DIR / "static/config/doc_config.json"
CREDENTIALS_PATH = ROOT_DIR / "static/credentials/ocrvenv-43bd1e531883.json"
