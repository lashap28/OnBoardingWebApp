import json

from onboarding.static.variables import CONFIG_PATH, TARGET_ANNOTATIONS, QUAD_CANDIDATES

with open(CONFIG_PATH) as f:
    dictionary = json.load(f)
    for doc_subtype, info in dictionary.items():
        target_annotations = info[TARGET_ANNOTATIONS]
        quad_candidates = info[QUAD_CANDIDATES]
        for quad in quad_candidates:
            if not all(x in target_annotations.keys() for x in quad):
                print(quad, doc_subtype)
