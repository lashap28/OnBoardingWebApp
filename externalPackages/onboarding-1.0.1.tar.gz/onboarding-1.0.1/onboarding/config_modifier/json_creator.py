import json
from onboarding.static.variables import *

target_annotations = {
    'და*ადე*ის': (287.5, 47.0),
    'და*ადე*ის_l': (242.0, 47.0),
    'და*ადე*ის_r': (333.0, 47.0),
    'ად*ილი': (373.5, 47.0),
    'ად*ილი_l': (341.0, 47.0),
    'ად*ილი_r': (406.0, 47.0),
    'PLACE': (445.5, 47.0),
    'PLACE_l': (421.0, 47.0),
    'PLACE_r': (470.0, 47.0),
    'BIRTH': (525.0, 47.0),
    'BIRTH_l': (503.0, 47.0),
    'BIRTH_r': (547.0, 47.0),
    '*აცემის': (276.0, 124.0),
    '*აცემის_l': (242.0, 123.5),
    '*აცემის_r': (310.0, 124.5),
    'თარიღი': (351.0, 125.0),
    'თარიღი_l': (318.0, 124.5),
    'თარიღი_r': (384.0, 125.5),
    'DATE': (419.0, 125.0),
    'DATE_l': (400.0, 125.0),
    'DATE_r': (438.0, 125.0),
    'ISSUE': (494.0, 126.0),
    'ISSUE_l': (471.0, 126.0),
    'ISSUE_r': (517.0, 126.0),
    'date_gela': (243.0, 151.5),
    '*ამცემი': (276.5, 175.5),
    '*ამცემი_l': (243.0, 175.5),
    '*ამცემი_r': (310.0, 175.5),
    'ორ*ანო': (350.0, 175.5),
    'ორ*ანო_l': (318.0, 175.5),
    'ორ*ანო_r': (382.0, 175.5),
    'ISSUING': (431.0, 175.5),
    'ISSUING_l': (399.0, 175.5),
    'ISSUING_r': (463.0, 175.5),
    'AUTHORITY': (516.0, 175.5),
    'AUTHORITY_l': (470.0, 175.5),
    'AUTHORITY_r': (562.0, 175.5),
    'იუსტიციის': (322.0, 205.0),
    'იუსტიციის_l': (245.0, 205.0),
    'იუსტიციის_r': (399.0, 205.0),
    'სამინისტრო': (496.0, 205.0),
    'სამინისტრო_l': (411.0, 205.0),
    'სამინისტრო_r': (581.0, 205.0),
    'MINISTRY': (295.0, 232.5),
    'MINISTRY_l': (244.0, 232.5),
    'MINISTRY_r': (346.0, 232.5),
    'JUSTICE': (434.5, 232.5),
    'JUSTICE_l': (390.0, 232.5),
    'JUSTICE_r': (479.0, 232.5),
    'IDGEO': (41.0, 364.0),
}
target_resolution = [800, 507]
quad_candidates = [
            [
                "MINISTRY_l",
                "მოქალაქეობა_l",
                "JUSTICE_r",
                "<"
            ],
            [
                "\u10d0\u10d3*\u10d8\u10da\u10d8_l",
                "GEO_r",
                "MINISTRY",
                "\u10d5\u10d0\u10d3\u10d0"
            ],
            [
                "\u10db\u10dd\u10e5\u10d0\u10da\u10d0\u10e5\u10d4\u10dd*\u10d0_l",
                "GEO_r",
                "JUSTICE_r",
                "<"
            ],
            [
                "\u10db\u10dd\u10e5\u10d0\u10da\u10d0\u10e5\u10d4\u10dd*\u10d0_l",
                "\u10dc\u10dd\u10db\u10d4\u10e0\u10d8_r",
                "\u10d8\u10e3\u10e1\u10e2\u10d8\u10ea\u10d8\u10d8\u10e1_l",
                "JUSTICE_r"
            ],
            [
                "\u10de\u10d8\u10e0\u10d0\u10d3\u10d8_l",
                "\u10dc\u10dd\u10db\u10d4\u10e0\u10d8_r",
                "\u10d8\u10e3\u10e1\u10e2\u10d8\u10ea\u10d8\u10d8\u10e1_l",
                "JUSTICE_r"
            ],
            [
                "GEO_l",
                "MINISTRY_l",
                "JUSTICE_r",
                "<"
            ],
            [
                "\u10e1\u10d0\u10ee\u10d4\u10da\u10d8_l",
                "GEO_r",
                "\u10d5\u10d0\u10d3\u10d0",
                "<"
            ],
            [
                "\u10e2\u10d8\u10de\u10d8",
                "GEO",
                "JUSTICE_r",
                "<"
            ],
            [
                "\u10d2\u10d5\u10d0\u10e0\u10d8_l",
                "\u10de\u10d8\u10e0\u10d0\u10d3\u10d8_r",
                "\u10d5\u10d0\u10d3\u10d0",
                "MINISTRY_l"
            ],
            [
                "\u10e1\u10d0\u10ee\u10d4\u10da\u10d8_l",
                "\u10dc\u10dd\u10db\u10d4\u10e0\u10d8_r",
                "GEO",
                "\u10dd\u10e0*\u10d0\u10dc\u10dd"
            ],
            [
                "TYPE",
                "GEO",
                "M",
                "<"
            ],
            [
                "\u10e2\u10d8\u10de\u10d8",
                "GEO",
                "F",
                "<"
            ],
            [
                "TYPE",
                "NUMBER",
                "EXPIRY",
                "ISSUING"
            ],
            [
                "SURNAME",
                "PERSONAL_r",
                "SIGNATURE",
                "AUTHORITY"
            ],
            [
                "\u10d9\u10dd\u10d3\u10d8",
                "\u10ee\u10d4\u10da\u10db\u10dd\u10ec\u10d4\u10e0\u10d0",
                "JUSTICE_r",
                "<"
            ],
            [
                "NAME",
                "PERSONAL_r",
                "EXPIRY_r",
                "ISSUE"
            ],
            [
                "TYPE",
                "NUMBER_r",
                "EXPIRY_r",
                "<"
            ],
            [
                "SURNAME",
                "PERSONAL",
                "PLACE",
                "ISSUING"
            ],
            [
                "TYPE_l",
                "GEO_r",
                "PLACE",
                "SIGNATURE"
            ],
            [
                "TYPE",
                "GEO_r",
                "JUSTICE",
                "<"
            ]
        ]
personal_info = {}


config_path = r"../static/config/doc_config.json"


def add_document(doc_type, save=False):
    doc_info = {
        TARGET_ANNOTATIONS: target_annotations,
        QUAD_CANDIDATES: quad_candidates,
        TARGET_RESOLUTION: target_resolution,
        PERSONAL_INFO: personal_info,
    }

    with open(config_path) as f:
        dictionary = json.load(f)
        dictionary[doc_type] = doc_info
        print(dictionary)

        json_object = json.dumps(dictionary, indent=4)
        print(json_object)

    if save:
        with open(config_path, 'w') as f:
            f.write(json_object)


def change_specific_info(doc_type, info_type):
    with open(config_path) as f:
        dictionary = json.load(f)
        dictionary[doc_type][info_type] = quad_candidates
        print(dictionary)

        json_object = json.dumps(dictionary, indent=4)
        print(json_object)

    with open(config_path, 'w') as f:
        f.write(json_object)


# add_document("id_back_geo_1", True)
change_specific_info("passport_geo_3", "quad_candidates")
