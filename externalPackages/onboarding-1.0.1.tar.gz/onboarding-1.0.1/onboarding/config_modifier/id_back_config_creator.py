import json
from ..static.variables import *
from ..static.codes.functions import bounding_box_to_point
from ..utils.scanned_image import ScannedImage

target_annotations = {
    'date_gela': (243.0, 151.5),
    'და*ადე*ის': (287.5, 47.0),
    'PLACE': (445.5, 47.0),
    'PLACE_l': (421.0, 47.0),
    'PLACE_r': (470.0, 47.0),
    'BIRTH': (525.0, 47.0),
    'BIRTH_l': (503.0, 47.0),
    'BIRTH_r': (547.0, 47.0),
    'DATE': (419.0, 125.0),
    'DATE_l': (400.0, 125.0),
    'DATE_r': (438.0, 125.0),
    'ISSUE': (494.0, 126.0),
    'ISSUE_l': (471.0, 126.0),
    'ISSUE_r': (517.0, 126.0),
    'ISSUING': (431.0, 175.5),
    'ISSUING_l': (399.0, 175.5),
    'ISSUING_r': (463.0, 175.5),
    'AUTHORITY': (516.0, 175.5),
    'AUTHORITY_l': (470.0, 175.5),
    'AUTHORITY_r': (562.0, 175.5),
    'MINISTRY': (295.0, 232.5),
    'MINISTRY_l': (244.0, 232.5),
    'MINISTRY_r': (346.0, 232.5),
    'JUSTICE': (434.5, 232.5),
    'JUSTICE_l': (390.0, 232.5),
    'JUSTICE_r': (479.0, 232.5),
    'No': (404.0, 268.0),
    'IDGEO': (41.0, 364.0),
    '9106042M3211290GEO': (250.5, 405.0),
}
target_resolution = (800, 507)
quad_candidates = [
    [
        "DATE_l",
        "ISSUE_r",
        "JUSTICE_r",
        "IDGEO",
    ],
    [
        "და*ადე*ის",
        "BIRTH",
        "AUTHORITY",
        "IDGEO"
    ],
    [
        "BIRTH",
        "date_gela",
        "JUSTICE",
        "IDGEO"
    ],
    [
        "და*ადე*ის",
        "BIRTH",
        "AUTHORITY",
        "IDGEO"
    ],
    [
        "PLACE",
        "ISSUE",
        "JUSTICE",
        "MINISTRY"
    ],
    [
        "PLACE",
        "ISSUE",
        "JUSTICE",
        "IDGEO"
    ],
    [
        "PLACE",
        "ISSUE",
        "JUSTICE",
        "IDGEO"
    ],
    [
        "PLACE",
        "DATE",
        "ISSUING",
        "IDGEO",
    ],
    [
        "BIRTH",
        "ISSUE",
        "AUTHORITY",
        "IDGEO"
    ],
    [
        "DATE",
        "AUTHORITY",
        "JUSTICE",
        "IDGEO"
    ],
    [
        "BIRTH",
        "DATE",
        "MINISTRY",
        "JUSTICE"
    ],
    [
        "PLACE",
        "ISSUE",
        "MINISTRY",
        "JUSTICE"
    ],
    [
        "BIRTH",
        "ISSUE",
        "AUTHORITY",
        "MINISTRY"
    ],
    [
        "PLACE",
        "DATE",
        "ISSUING",
        "MINISTRY"
    ]
]
personal_info = {
}

config_path = r"../static/config/doc_config.json"


def add_document(doc_type, save=False):
    doc_info = {
        TARGET_ANNOTATIONS: target_annotations,
        QUAD_CANDIDATES: quad_candidates,
        TARGET_RESOLUTION: target_resolution,
        PERSONAL_INFO: personal_info,
    }

    with open(config_path) as f:
        dictionary = json.load(f)
        dictionary[doc_type] = doc_info
        print(dictionary)

        json_object = json.dumps(dictionary, indent=4)
        print(json_object)

    if save:
        with open(config_path, 'w') as f:
            f.write(json_object)


add_document("id_back_geo_1", True)
