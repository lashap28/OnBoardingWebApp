from onboarding.static.codes.functions import bounding_box_to_point

from onboarding.utils.scanned_image import ScannedImage


def get_doc_info(image_path):
    sd = ScannedImage(image_path, None)
    annotations = bounding_box_to_point(sd.scanned_annotations)
    print(sd.scanned_annotations)
    print(annotations)



image_path = r'/onboarding/static/target_pictures/passport_old_geo.jpg'


get_doc_info(image_path)
